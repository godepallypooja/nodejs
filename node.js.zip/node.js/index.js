function average(a,b){
    return (a+b)/2;
}
const math={
    sum:(a,b)=>a+b,
    multiply:(a,b)=>{
        return a*b
    },
    avg: (a,b)=>average(a,b)
}
console.log(math.sum(10,20))
console.log(math.multiply(10,30))
console.log(math.avg(2,3))

console.log("hello world")


module.exports = math