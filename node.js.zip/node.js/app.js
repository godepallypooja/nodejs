const math = require("./index.js")
const pokemon = require('pokemon');
const nodeemoji=require('node-emoji')

//const cartoon=require('cartoon')

//console.log(math.sum(10,15))


const os=require('node:os');
//console.log(os.cpus())
//console.log(pokemon.all())
//console.log(os.cpus())
//console.log(cartoon.all())
console.log(nodeemoji.find('🦄'))
