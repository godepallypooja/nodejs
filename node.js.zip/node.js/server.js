const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');

const server = http.createServer((req, res) => {
    const requestedUrl = req.url;
    let filePath = './frontend/home.html'; // Default file

    if (requestedUrl === '/home') {
        filePath = './frontend/home.html';
    } else if (requestedUrl === '/contact') {
        filePath = './frontend/contact.html';
    } else if (requestedUrl === '/about') {
        filePath = './frontend/about.html';
    } else if (requestedUrl === '/services') {
        filePath = './frontend/services.html';
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        return res.end('<h1>404 Not Found</h1>');
    }

    // Read the requested file
    fs.readFile(filePath, 'utf-8', (err, data) => {
        if (err) {
            console.error("Error while reading file", err);
            res.writeHead(500, { 'Content-Type': 'text/html' });
            return res.end('<h1>500 Internal Server Error</h1>');
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
    });
});

server.listen(3001, () => {
    console.log('Server is listening on port 3000');
});